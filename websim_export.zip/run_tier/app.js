const form = document.querySelector('#run-form');
const distanceInput = document.querySelector('#distance');
const tempoInput = document.querySelector('#tempo');
const error = document.querySelector('#form-error');
const result = document.querySelector('#result');
const submitRunButton = document.querySelector('#submit-run');
const submitStatus = document.querySelector('#submit-status');
const boardStatus = document.querySelector('#board-status');
const runnerList = document.querySelector('#runner-list');
const runnerCount = document.querySelector('#runner-count');
const myPlace = document.querySelector('#my-place');
const myPlaceContent = document.querySelector('#my-place-content');
let latestRun = null;
let canSubmit = false;

const tiers = [
  { name: 'Starter', note: 'Every run counts. You are building your base.' },
  { name: 'Cruiser', note: 'A steady rhythm with room to pick up the pace.' },
  { name: 'Strong', note: 'A solid all-round run. Keep stacking those miles.' },
  { name: 'Fast', note: 'Quick feet and a strong engine. Nicely done.' },
  { name: 'Elite', note: 'Seriously quick. You are moving in rare company.' }
];

function parsePace(value) {
  const match = value.trim().match(/^(\d{1,2}):([0-5]\d)$/);
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

function formatPace(totalSeconds) {
  const seconds = Math.round(totalSeconds);
  return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
}

function formatDuration(totalMinutes) {
  const totalSeconds = Math.round(totalMinutes * 60);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return hours
    ? hours + ':' + String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0')
    : minutes + ':' + String(seconds).padStart(2, '0');
}

function formatDistance(distance) {
  return Number(distance).toLocaleString(undefined, { maximumFractionDigits: 2 });
}

function makeProfile(username) {
  const link = document.createElement('a');
  link.className = 'runner-profile';
  link.href = 'https://websim.com/@' + encodeURIComponent(username);
  link.target = '_blank';
  link.rel = 'noopener noreferrer';

  const avatar = document.createElement('img');
  avatar.className = 'runner-avatar';
  avatar.src = 'https://images.websim.com/avatar/' + encodeURIComponent(username);
  avatar.alt = '';
  avatar.loading = 'lazy';
  link.append(avatar);

  const name = document.createElement('span');
  name.className = 'runner-name';
  name.textContent = '@' + username;
  link.append(name);
  return link;
}

function makeRunnerRow(entry) {
  const row = document.createElement('li');
  row.className = 'runner-row';

  const rank = document.createElement('span');
  rank.className = 'runner-rank' + (entry.rank <= 3 ? ' top-rank' : '');
  rank.textContent = String(entry.rank).padStart(2, '0');
  row.append(rank, makeProfile(entry.username));

  const metrics = document.createElement('span');
  metrics.className = 'runner-metrics';
  const distance = document.createElement('strong');
  distance.textContent = formatDistance(entry.distance_km) + ' km';
  const pace = document.createElement('small');
  pace.textContent = formatPace(entry.equivalent_seconds) + ' /km eq.';
  metrics.append(distance, pace);
  row.append(metrics);

  const tier = document.createElement('span');
  tier.className = 'tier-pill tier-' + entry.tier;
  tier.textContent = tiers[entry.tier].name;
  row.append(tier);
  return row;
}

function showMyPlace(entry) {
  if (!entry) {
    myPlace.hidden = true;
    return;
  }
  myPlaceContent.replaceChildren();
  const rank = document.createElement('strong');
  rank.className = 'my-rank';
  rank.textContent = '#' + entry.rank;
  const profile = makeProfile(entry.username);
  const details = document.createElement('span');
  details.className = 'my-place-details';
  details.textContent = formatDistance(entry.distance_km) + ' km · ' + formatPace(entry.pace_seconds) + ' /km · ' + tiers[entry.tier].name;
  myPlaceContent.append(rank, profile, details);
  myPlace.hidden = false;
}

async function loadLeaderboard() {
  try {
    const response = await fetch('/api/leaderboard?limit=10');
    if (!response.ok) throw new Error('Could not load the leaderboard.');
    const data = await response.json();
    canSubmit = data.canSubmit;
    runnerCount.textContent = data.total + (data.total === 1 ? ' RUNNER' : ' RUNNERS');
    runnerList.replaceChildren(...data.entries.map(makeRunnerRow));
    boardStatus.textContent = data.total ? '' : 'No runs on the board yet. Be the first to share one.';
    showMyPlace(data.mine);
    if (!latestRun) {
      submitRunButton.disabled = true;
      submitStatus.textContent = canSubmit ? 'Submit your run to claim your place.' : 'Sign in to submit your run.';
    }
  } catch {
    boardStatus.textContent = 'The leaderboard could not load right now.';
    runnerCount.textContent = '— RUNNERS';
  }
}

function clearCurrentResult() {
  result.hidden = true;
  latestRun = null;
  submitRunButton.disabled = true;
  submitStatus.textContent = canSubmit ? 'Submit your run to claim your place.' : 'Sign in to submit your run.';
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const distance = Number(distanceInput.value);
  const paceSeconds = parsePace(tempoInput.value);

  if (!Number.isFinite(distance) || distance < 0.1 || distance > 300) {
    error.textContent = 'Enter a distance from 0.1 to 300 km.';
    clearCurrentResult();
    distanceInput.focus();
    return;
  }
  if (paceSeconds === null || paceSeconds < 60 || paceSeconds > 1800) {
    error.textContent = 'Enter tempo as minutes:seconds per km, like 5:30.';
    clearCurrentResult();
    tempoInput.focus();
    return;
  }

  error.textContent = '';
  const equivalentSeconds = Math.max(60, Math.round(paceSeconds + 24 * Math.log2(5 / distance)));
  const equivalentPace = equivalentSeconds / 60;
  const tierIndex = equivalentPace >= 7.5 ? 0 : equivalentPace >= 6.5 ? 1 : equivalentPace >= 5.5 ? 2 : equivalentPace >= 4.5 ? 3 : 4;
  const tier = tiers[tierIndex];
  latestRun = { distanceKm: distance, paceSeconds };

  document.querySelector('#tier-name').textContent = tier.name;
  document.querySelector('#tier-index').textContent = 'TIER ' + String(tierIndex + 1).padStart(2, '0') + ' / 05';
  document.querySelector('#tier-symbol').textContent = ['·', '↗', '✳', '✦', '★'][tierIndex];
  document.querySelector('#meter-fill').style.width = ((tierIndex + 1) * 20) + '%';
  document.querySelector('#equivalent-pace').innerHTML = formatPace(equivalentSeconds) + ' <small>/ KM</small>';
  document.querySelector('#run-time').textContent = formatDuration(distance * paceSeconds / 60);
  document.querySelector('#result-note').textContent = tier.note;
  submitRunButton.disabled = !canSubmit;
  submitStatus.textContent = canSubmit ? 'Only your best run is kept on the board.' : 'Sign in to submit your run.';
  result.hidden = false;
});

tempoInput.addEventListener('input', () => {
  tempoInput.value = tempoInput.value.replace(/[^\d:]/g, '').slice(0, 5);
  error.textContent = '';
  clearCurrentResult();
});
distanceInput.addEventListener('input', () => {
  error.textContent = '';
  clearCurrentResult();
  document.querySelectorAll('.trail-select').forEach((button) => button.setAttribute('aria-pressed', 'false'));
});

document.querySelectorAll('.trail-select').forEach((button) => {
  button.addEventListener('click', () => {
    distanceInput.value = button.dataset.distance;
    distanceInput.dispatchEvent(new Event('input', { bubbles: true }));
    button.setAttribute('aria-pressed', 'true');
    document.querySelector('#trail-status').textContent = button.dataset.name + ' loaded · ' + button.dataset.distance + ' km. Add your tempo above.';
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
});

submitRunButton.addEventListener('click', async () => {
  if (!latestRun || !canSubmit) return;
  submitRunButton.disabled = true;
  submitStatus.textContent = 'Adding your best run…';
  try {
    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(latestRun)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not submit this run.');
    showMyPlace(data.mine);
    submitStatus.textContent = data.personalBest
      ? 'Personal best saved. You are #' + data.mine.rank + ' in the pack.'
      : 'Your faster personal best is already on the board at #' + data.mine.rank + '.';
    await loadLeaderboard();
  } catch (submitError) {
    submitStatus.textContent = submitError.message || 'Could not submit this run. Try again.';
  } finally {
    submitRunButton.disabled = !canSubmit || !latestRun;
  }
});

loadLeaderboard();
