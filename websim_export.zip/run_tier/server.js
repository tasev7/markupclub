export const schema = 
  "CREATE TABLE IF NOT EXISTS runs (user_id TEXT PRIMARY KEY, username TEXT NOT NULL, distance_km REAL NOT NULL, pace_seconds INTEGER NOT NULL, equivalent_seconds INTEGER NOT NULL, tier INTEGER NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP); CREATE INDEX IF NOT EXISTS runs_rank ON runs (equivalent_seconds ASC, distance_km DESC, username COLLATE NOCASE ASC)";

const rankSql = "(SELECT COUNT(*) + 1 FROM runs AS ahead WHERE ahead.equivalent_seconds < runs.equivalent_seconds OR (ahead.equivalent_seconds = runs.equivalent_seconds AND ahead.distance_km > runs.distance_km) OR (ahead.equivalent_seconds = runs.equivalent_seconds AND ahead.distance_km = runs.distance_km AND ahead.username COLLATE NOCASE < runs.username COLLATE NOCASE)) AS rank";
const selectEntry = "SELECT username, distance_km, pace_seconds, equivalent_seconds, tier, updated_at, " + rankSql + " FROM runs";

function getTier(equivalentSeconds) {
  if (equivalentSeconds >= 450) return 0;
  if (equivalentSeconds >= 390) return 1;
  if (equivalentSeconds >= 330) return 2;
  if (equivalentSeconds >= 270) return 3;
  return 4;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const userId = request.headers.get("x-websim-user-id");

    if (request.method === "GET" && url.pathname === "/api/leaderboard") {
      const limit = Math.min(20, Math.max(1, Number(url.searchParams.get("limit")) || 10));
      const [{ results: entries }, total] = await Promise.all([
        env.DB.prepare(selectEntry + " ORDER BY equivalent_seconds ASC, distance_km DESC, username COLLATE NOCASE ASC LIMIT ?").bind(limit).all(),
        env.DB.prepare("SELECT COUNT(*) AS total FROM runs").first("total")
      ]);
      const mine = userId ? await env.DB.prepare(selectEntry + " WHERE user_id = ?").bind(userId).first() : null;
      return Response.json({ entries, total, mine, canSubmit: Boolean(userId) });
    }

    if (request.method === "POST" && url.pathname === "/api/submit") {
      if (!userId) return Response.json({ error: "Sign in to submit a run." }, { status: 401 });
      const username = request.headers.get("x-websim-username");
      if (!username) return Response.json({ error: "Your account name could not be verified." }, { status: 401 });

      let input;
      try {
        input = await request.json();
      } catch {
        return Response.json({ error: "Invalid request." }, { status: 400 });
      }
      const distance = Number(input.distanceKm);
      const paceSeconds = Number(input.paceSeconds);
      if (!Number.isFinite(distance) || distance < 0.1 || distance > 300 || !Number.isInteger(paceSeconds) || paceSeconds < 60 || paceSeconds > 1800) {
        return Response.json({ error: "Enter a valid distance and tempo." }, { status: 400 });
      }

      const distanceKm = Math.round(distance * 100) / 100;
      const equivalentSeconds = Math.max(60, Math.round(paceSeconds + 24 * Math.log2(5 / distanceKm)));
      const tier = getTier(equivalentSeconds);
      const write = await env.DB.prepare(
        "INSERT INTO runs (user_id, username, distance_km, pace_seconds, equivalent_seconds, tier) VALUES (?, ?, ?, ?, ?, ?) " +
        "ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, distance_km = excluded.distance_km, pace_seconds = excluded.pace_seconds, equivalent_seconds = excluded.equivalent_seconds, tier = excluded.tier, updated_at = CURRENT_TIMESTAMP " +
        "WHERE excluded.equivalent_seconds < runs.equivalent_seconds OR (excluded.equivalent_seconds = runs.equivalent_seconds AND excluded.distance_km > runs.distance_km)"
      ).bind(userId, username, distanceKm, paceSeconds, equivalentSeconds, tier).run();
      const mine = await env.DB.prepare(selectEntry + " WHERE user_id = ?").bind(userId).first();
      return Response.json({ ok: true, personalBest: write.meta.changes > 0, mine });
    }

    return new Response("Not found", { status: 404 });
  }
};
